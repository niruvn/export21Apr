# Copyright 2017 Canonical Ltd.
# Licensed under the LGPLv3, see LICENCE file for details.


VERSION_0 = 0
VERSION_1 = 1
VERSION_2 = 2
VERSION_3 = 3
LATEST_VERSION = VERSION_3
