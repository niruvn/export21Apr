This package provides the debianbts module, which allows to query Debian's Bug Tracking System.


