from __future__ import absolute_import

from debianbts.debianbts import *
from debianbts.version import __version__
