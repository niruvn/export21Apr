
PyMacaroons
===========

PyMacaroons is a Python implementation of Macaroons. *They're better than cookies!*

Installation
------------

Install PyMacaroons by running:

    pip install pymacaroons

Contribute
----------

- `Issue Tracker`_
- `Source Code`_

.. _Issue Tracker: https://github.com/ecordell/pymacaroons/issues
.. _Source Code: https://github.com/ecordell/pymacaroons

License
-------

The project is licensed under the MIT license.




