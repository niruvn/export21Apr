Windows Support
===============

This page has been split up and moved to the new section :ref:`windows`.
