.. _basic_concepts:

****************
Ansible concepts
****************

These concepts are common to all uses of Ansible. You need to understand them to use Ansible for any kind of automation. This basic introduction provides the background you need to follow the rest of the User Guide.

.. contents::
   :local:

.. include:: /shared_snippets/basic_concepts.txt
